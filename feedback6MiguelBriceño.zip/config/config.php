<?php
    //? Definición de path
    define("URLSITE","http://localhost/feedback6MiguelBriceño/" );

?>