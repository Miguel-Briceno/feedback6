<?php
//? Definición de las constantes de conexión a la base de datos
    define('HOST', 'localhost');
    define('DBNAME', 'productosfeedback6');
    define('USER', 'root');
    define('PASSWORD', '');
?>